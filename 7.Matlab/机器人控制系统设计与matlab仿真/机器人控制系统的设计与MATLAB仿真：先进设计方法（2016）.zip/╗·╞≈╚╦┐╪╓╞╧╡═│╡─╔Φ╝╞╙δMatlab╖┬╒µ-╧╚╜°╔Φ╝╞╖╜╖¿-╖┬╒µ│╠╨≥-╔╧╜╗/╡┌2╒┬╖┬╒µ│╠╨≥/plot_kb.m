clear all;
close all;

figure(1);
kb1=1.51;
plot(-kb1,[-1:0.001:1],'k');
