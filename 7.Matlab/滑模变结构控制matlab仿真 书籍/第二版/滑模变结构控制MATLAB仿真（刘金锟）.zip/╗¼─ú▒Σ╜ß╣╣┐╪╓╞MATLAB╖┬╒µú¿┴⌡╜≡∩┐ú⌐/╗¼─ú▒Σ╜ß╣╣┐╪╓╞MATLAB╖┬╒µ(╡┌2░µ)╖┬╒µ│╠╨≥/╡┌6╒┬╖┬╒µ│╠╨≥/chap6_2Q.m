clear all;
close all;

c1=10;
k1=15;
h=20;

Q=[c1+h*k1^2 h*k1-0.5; h*k1-0.5 h];

h*(c1+k1)-0.25