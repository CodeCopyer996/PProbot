close all;


x1=x(:,1);
x2=x(:,2);
x3=x(:,3);

plot3(x3,x2,x1);
xlabel('x3');ylabel('x2');zlabel('x1');